const app = new Vue({
    el: '#app',
    data: {

    },

    methods: {
    },

});